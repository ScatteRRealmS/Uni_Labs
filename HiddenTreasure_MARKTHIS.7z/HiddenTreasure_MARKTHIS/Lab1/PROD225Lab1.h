#pragma once

int xAxis;
int yAxis;