#include <iostream>
#include <conio.h>

#define LEFT 75
#define RIGHT 77
#define UP 72
#define DOWN 80
#define PRESSED 224

int main()
{
    unsigned char KeyPressed = '\0';
    do
    {
        KeyPressed = _getch();
        if (KeyPressed == PRESSED)
        {
            char ArrowKey = _getch();
            switch (ArrowKey)
            {
            case LEFT:
                std::cout << "Left" << std::endl;
                break;
            case RIGHT:
                std::cout << "Right" << std::endl;
                break;
            case UP:
                std::cout << "Up" << std::endl;
                break;
            case DOWN:
                std::cout << "Down" << std::endl;
                break;
            default:
                break;
            }
        }
    } while (KeyPressed != 'q' && KeyPressed != 'Q');

    return 0;
}