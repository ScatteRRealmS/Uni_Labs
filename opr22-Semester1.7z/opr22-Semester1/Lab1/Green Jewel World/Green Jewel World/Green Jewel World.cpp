#include <iostream>
#include <conio.h>
#include <cstdlib>
#include "prod225colour.h"
#include <string>
#include <algorithm>


#define LEFT 75
#define RIGHT 77
#define UP 72
#define DOWN 80
#define PRESSED 224
#define QUIT ('q')

//This is a mess, should be split up into functions, random placing has a chance to spawn treasure
//in the same place. And output messages dont exactly match with colours.


void main() {

    int PlayerYPosition = 0;
    int PlayerXPosition = 0;
    int MaxX = 50;
    int MaxY = 10;

    int NumberOfMoves = 0;

    bool Treasure1Collected = false;
    bool Treasure2Collected = false;
    bool Treasure3Collected = false;
    bool Treasure4Collected = false;
    bool AllCollected = false;

    //Generate random values for treasure

    int Treasure1y = rand() % 10;
    int Treasure1x = rand() % 50;
    int Treasure2y = rand() % 10;
    int Treasure2x = rand() % 50;
    int Treasure3y = rand() % 10;
    int Treasure3x = rand() % 50;
    int Treasure4y = rand() % 10;
    int Treasure4x = rand() % 50;

    //Prints the grid using nested for loops, checking if the player or treasure is in that position
    //Changes colour and prints player or treasure if so

    do {
        for (int y = 0; y < 10; y++)
        {
            for (int x = 0; x < 50; x++)
            {
                if (x == PlayerXPosition && y == PlayerYPosition)
                {
                    SetTextColour(0, 15);
                    std::cout << "P";
                }
                else if (x == Treasure1x && y == Treasure1y)
                {
                    if (Treasure1Collected == false)
                    {
                        SetTextColour(0, 9);
                        std::cout << "c";
                    }
                    else {
                        std::cout << "-";
                    }
                }
                else if (x == Treasure2x && y == Treasure2y)
                {
                    if (Treasure2Collected == false)
                    {
                        SetTextColour(0, 4);
                        std::cout << "d";
                    }
                    else {
                        std::cout << "-";
                    }
                }
                else if (x == Treasure3x && y == Treasure3y)
                {
                    if (Treasure3Collected == false)
                    {
                        SetTextColour(0, 13);
                        std::cout << "a";
                    }
                    else {
                        std::cout << "-";
                    }
                }
                else if (x == Treasure4x && y == Treasure4y)
                {
                    if (Treasure4Collected == false)
                    {
                        SetTextColour(0, 2);
                        std::cout << "b";
                    }
                    else {
                        std::cout << "-";
                    }
                }
                else
                {
                    SetTextColour(15, 2);
                    std::cout << "-";
                }
                //This should be in its own function
                if (Treasure1x == PlayerXPosition && Treasure1y == PlayerYPosition) 
                {
                    Treasure1Collected = true;
                }
                else if (Treasure2x == PlayerXPosition && Treasure2y == PlayerYPosition)
                {
                    Treasure2Collected = true;
                }
                else if (Treasure3x == PlayerXPosition && Treasure3y == PlayerYPosition)
                {
                    Treasure3Collected = true;
                }
                else if (Treasure4x == PlayerXPosition && Treasure4y == PlayerYPosition)
                {
                    Treasure4Collected = true;
                }
                if (Treasure1Collected && Treasure2Collected && Treasure3Collected && Treasure4Collected)
                {
                    AllCollected = true;
                }

            }
            std::cout << std::endl;

            //Get player input and update, this needs to be in its own function eventually
        }
        unsigned char KeyPressed = '\0';

            KeyPressed = _getch();
            if (KeyPressed == 'q' || KeyPressed == 'Q')
            {
                SetTextColour(15, 0);
                std::cout << "Oh No! You quit" << std::endl;
                SetTextColour(5, 0);
                std::cout << "[] ";
                SetTextColour(12, 0);
                std::cout << "[] ";
                SetTextColour(4, 0);
                std::cout << "[] ";
                SetTextColour(14, 0);
                std::cout << "[] ";
                SetTextColour(15, 0);
                std::cout << "Game over! ";
                SetTextColour(4, 0);
                std::cout << "[] ";
                SetTextColour(15, 0);
                std::cout << "[] ";
                SetTextColour(14, 0);
                std::cout << "[] ";
                SetTextColour(12, 0);
                break;
            }
            //Moves the player, updates counter, checks for edge of world
            if (KeyPressed == PRESSED)
            {
                char ArrowKey = _getch();
                switch (ArrowKey)
                {
                case LEFT:
                    if (PlayerXPosition >= 1)
                    {
                        PlayerXPosition -= 1;
                        NumberOfMoves += 1;
                    }


                    break;
                case RIGHT:
                    if (PlayerXPosition <= 48)
                    {
                        PlayerXPosition += 1;
                        NumberOfMoves += 1;
                    }


                    break;
                case UP:
                    if (PlayerYPosition >= 1)
                    {
                        PlayerYPosition -= 1;
                        NumberOfMoves += 1;
                    }

                    break;
                case DOWN:
                    if (PlayerYPosition <= 8)
                    {
                        PlayerYPosition += 1;
                        NumberOfMoves += 1;
                    }

                    break;


                }
            }

    } while (!AllCollected);

    //Currently end condition uses Q or collecting all treasures with same bool
    //Only difference is it prints extra if game is ended by AllCollected
    //This needs to be fixed
    //Also currently the player must move one more space exactly after finding all gems to correctly print message
    if (AllCollected)
    {

        SetTextColour(5, 0);
        std::cout << "[] ";
        SetTextColour(12, 0);
        std::cout << "[] ";
        SetTextColour(4, 0);
        std::cout << "[] ";
        SetTextColour(14, 0);
        std::cout << "[] ";
        SetTextColour(15, 0);
        std::cout << "Well done! ";
        SetTextColour(4, 0);
        std::cout << "[] ";
        SetTextColour(15, 0);
        std::cout << "[] ";
        SetTextColour(14, 0);
        std::cout << "[] ";
        SetTextColour(12, 0);
        std::cout << "[] " << std::endl;
        SetTextColour(15, 0);
        std::cout << "You collected all four jewels!" << std::endl;
        std::cout << "It took you " << NumberOfMoves << " moves!" << std::endl;
        SetTextColour(5, 0);
        std::cout << "[] ";
        SetTextColour(12, 0);
        std::cout << "[] ";
        SetTextColour(4, 0);
        std::cout << "[] ";
        SetTextColour(14, 0);
        std::cout << "[] ";
        SetTextColour(15, 0);
        std::cout << "Game over! ";
        SetTextColour(4, 0);
        std::cout << "[] ";
        SetTextColour(15, 0);
        std::cout << "[] ";
        SetTextColour(14, 0);
        std::cout << "[] ";
        SetTextColour(12, 0);
        std::cout << "[] " << std::endl;
    }
}


