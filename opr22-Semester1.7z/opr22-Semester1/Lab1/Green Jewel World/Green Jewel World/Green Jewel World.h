#pragma once

//int xPosition;
//int yPosition;
int PlayerXPosition;
int PlayerYPosition;
int MaxX;
int MaxY;
int NumberOfMoves;

bool Treasure1Collected;
bool Treasure2Collected;
bool Treasure3Collected;
bool Treasure4Collected;
unsigned char KeyPressed;
//void GridBuild();