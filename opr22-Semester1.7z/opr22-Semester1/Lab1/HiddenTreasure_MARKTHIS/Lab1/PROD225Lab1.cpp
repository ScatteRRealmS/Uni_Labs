#include <iostream>
#include <conio.h>
#include <string>
#include <cstdlib>
#include "prod225colour.h"

//Declares variables to be used in do loop later
int xAxis = 0;
int yAxis = 0;
std::string Choice;


int main()
{
    //Starts with some intro text
    std::cout << "Find the hidden treasure!" << std::endl;
    std::cout << "-------------------------" << std::endl;
    std::cout << std::endl;
    std::cout << "Press 'Q' to quit at any time..." << std::endl;
    std::cout << std::endl;
    //Sets bool to false, so we can later set to true to exit the do loop
    bool bQuit = false;
    do
    {

        std::cout << "You are at (" << xAxis << ", " << yAxis << "). Move (N/E/S/W)?" << std::endl;
        std::cin >> Choice;
        std::cout << std::endl;
        

        if (Choice == "N" || Choice == "n")
        {
            //Checks if outside the bounds of the world and if so does not let player go further, otherwise moves one point along the axis
            if (yAxis < 10)
            {
                yAxis += 1;
            }
            else
            {
                std::cout << "+-----------------------------------------+" << std::endl;
                std::cout << "| You have reached the edge of the world! |" << std::endl;
                std::cout << "+-----------------------------------------+" << std::endl;
            }
        }
        else if (Choice == "E" || Choice == "e")
        {

            if (xAxis < 10)
            {
                xAxis += 1;
            }
            else
            {
                std::cout << "+-----------------------------------------+" << std::endl;
                std::cout << "| You have reached the edge of the world! |" << std::endl;
                std::cout << "+-----------------------------------------+" << std::endl;
            }
        }
        else if (Choice == "S" || Choice == "s")
        {
            if (yAxis > -10)
            {
                yAxis -= 1;
            }
            else
            {
                std::cout << "+-----------------------------------------+" << std::endl;
                std::cout << "| You have reached the edge of the world! |" << std::endl;
                std::cout << "+-----------------------------------------+" << std::endl;
            }
        }
        else if (Choice == "W" || Choice == "w")
        {
            if (xAxis > -10)
            {
                xAxis -= 1;
            }
            else
            {
                std::cout << "+-----------------------------------------+" << std::endl;
                std::cout << "| You have reached the edge of the world! |" << std::endl;
                std::cout << "+-----------------------------------------+" << std::endl;
            }
        }

        else if (Choice == "q" || Choice == "Q")
        {
            //Allows player to quit with Q
            std::cout << "Goodbye!";
            bQuit = true;

        }
        else 
            //If any other commands are given
        {
            std::cout << "Not a valid direction please try again" << std::endl;
        }
        //Treasure hidden at co-ordinates, that display messages when found
        if (xAxis == 2 && yAxis == 3)
        {
            std::cout << "******************************" << std::endl;
            std::cout << "* You found a pirates chest! *" << std::endl;
            std::cout << "******************************" << std::endl;
        }
        if (xAxis == -5 && yAxis == -3)
        {
            std::cout << "****************************" << std::endl;
            std::cout << "* You found a golden idol! *" << std::endl;
            std::cout << "****************************" << std::endl;
        }
        if (xAxis == 1 && yAxis == -2)
        {
            std::cout << "*********************************" << std::endl;
            std::cout << "* You found precious gemstones! *" << std::endl;
            std::cout << "*********************************" << std::endl;
        }
        if (xAxis == 5 && yAxis == 2)
        {
            std::cout << "*****************************" << std::endl;
            std::cout << "* You found a lost artwork! *" << std::endl;
            std::cout << "*****************************" << std::endl;
        }
        if (xAxis == 10 && yAxis == 10)
        {
            std::cout << "**************************************" << std::endl;
            std::cout << "* You found a cursed skull talisman! *" << std::endl;
            std::cout << "**************************************" << std::endl;
        }

    } while (bQuit != true);

    return 0;
}