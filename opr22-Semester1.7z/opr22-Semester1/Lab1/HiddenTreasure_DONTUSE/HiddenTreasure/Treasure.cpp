#include <iostream>
#include <conio.h>
#include <cstdlib>
#include "prod225colour.h"

int main()
{
    unsigned char key_pressed = '\0';
    do
    {
        key_pressed = _getch();
        if (key_pressed == 224)
        {
            char arrow_key = _getch();
            switch (arrow_key)
            {
            case 75:
                std::cout << "Left" << std::endl;
                break;
            case 77:
                std::cout << "Right" << std::endl;
                break;
            case 72:
                std::cout << "Up" << std::endl;
                break;
            case 80:
                std::cout << "Down" << std::endl;
                break;
            default:
                break;
            }
        }
    } while (key_pressed != 'q' && key_pressed != 'Q');

    return 0;
}