#include <iostream>
#include <conio.h>
#include "Tic Tac Toe.h"


//Tic Tac Toe Game!

//Need to implement Structs for cells

//struct Cell
//{
//	char Value;
//	int Column;
//	int Row;
//	
//};

//class BoardDraw {


	void BoardDraw::InitializeBoard() {

		//Creates the 2d array, needs to be converted to a struct array
		int Value = 49;

		for (int x = 0; x < 9; x++) {

			int Row = (x / GridSize);
			int Column = (x % GridSize);

			//char Position = Board[Row][Column];
			Board[Row][Column] = Value;
			Value += 1;

		}

	}

	void BoardDraw::PrintBoard() {
		//Loop to print values in arrays with some borders

		for (int x = 0; x < 9; x++) {
			int Row = (x / GridSize);
			int Column = (x % GridSize);
			char Position = Board[Row][Column];
			std::cout << Position << " | ";
			if (Column == 2) {

				std::cout << std::endl;
				std::cout << std::endl << "---+---+---" << std::endl;

			}

		}

	}

	void BoardDraw::PlayerPlay() {

		//Can use modulo to get this down to one call but haven't figured out how
		//to convert _getch into an int


		unsigned char KeyPressed = '\0';

		//Switches prompt based on player

		if (ActivePlayerx)
		{
			std::cout << "X's turn: " << std::endl;
		}
		else
		{
			std::cout << "Y's turn: " << std::endl;
		}

		KeyPressed = _getch();

		//This is so overly complex needs fixing

		if (KeyPressed == '1') {

			if (Board[0][0] == '1') {
				if (ActivePlayerx == true)
				{
					Board[0][0] = 'X';
					ActivePlayerx = false;


				}
				else
				{
					Board[0][0] = 'Y';
					ActivePlayerx = true;

				}
			}
			else {
				std::cout << "That space is taken!" << std::endl;
				std::cout << std::endl;
			}
		}
		if (KeyPressed == '2') {
			if (Board[0][1] == '2') {
				if (ActivePlayerx == true)
				{
					Board[0][1] = 'X';
					ActivePlayerx = false;


				}
				else
				{
					Board[0][1] = 'Y';
					ActivePlayerx = true;


				}
			}
			else {
				std::cout << "That space is taken!" << std::endl;
				std::cout << std::endl;
			}
		}
		if (KeyPressed == '3') {
			if (Board[0][2] == '3') {
				if (ActivePlayerx == true)
				{
					Board[0][2] = 'X';
					ActivePlayerx = false;
					//Cell1Claimed = true;

				}
				else
				{
					Board[0][2] = 'Y';
					ActivePlayerx = true;
					//Cell1Claimed = true;

				}
			}
			else {
				std::cout << "That space is taken!" << std::endl;
				std::cout << std::endl;
			}
		}
		if (KeyPressed == '4') {
			if (Board[1][0] == '4') {
				if (ActivePlayerx == true)
				{
					Board[1][0] = 'X';
					ActivePlayerx = false;
					//Cell1Claimed = true;

				}
				else
				{
					Board[1][0] = 'Y';
					ActivePlayerx = true;
					//Cell1Claimed = true;

				}
			}
			else {
				std::cout << "That space is taken!" << std::endl;
				std::cout << std::endl;
			}
		}
		if (KeyPressed == '5') {
			if (Board[1][1] == '5') {
				if (ActivePlayerx == true)
				{
					Board[1][1] = 'X';
					ActivePlayerx = false;
					//Cell1Claimed = true;

				}
				else
				{
					Board[1][1] = 'Y';
					ActivePlayerx = true;
					//Cell1Claimed = true;

				}
			}
			else {
				std::cout << "That space is taken!" << std::endl;
				std::cout << std::endl;
			}
		}
		if (KeyPressed == '6') {
			if (Board[1][2] == '6') {
				if (ActivePlayerx == true)
				{
					Board[1][2] = 'X';
					ActivePlayerx = false;
					//Cell1Claimed = true;

				}
				else
				{
					Board[1][2] = 'Y';
					ActivePlayerx = true;
					//Cell1Claimed = true;

				}
			}
			else {
				std::cout << "That space is taken!" << std::endl;
				std::cout << std::endl;
			}
		}
		if (KeyPressed == '7') {
			if (Board[2][0] == '7') {
				if (ActivePlayerx == true)
				{
					Board[2][0] = 'X';
					ActivePlayerx = false;
					//Cell1Claimed = true;

				}
				else
				{
					Board[2][0] = 'Y';
					ActivePlayerx = true;
					//Cell1Claimed = true;

				}
			}
			else {
				std::cout << "That space is taken!" << std::endl;
				std::cout << std::endl;
			}
		}
		if (KeyPressed == '8') {
			if (Board[2][1] == '8') {
				if (ActivePlayerx == true)
				{
					Board[2][1] = 'X';
					ActivePlayerx = false;
					//Cell1Claimed = true;

				}
				else
				{
					Board[2][1] = 'Y';
					ActivePlayerx = true;
					//Cell1Claimed = true;

				}
			}
			else {
				std::cout << "That space is taken!" << std::endl;
				std::cout << std::endl;
			}
		}
		if (KeyPressed == '9') {
			if (Board[2][2] == '9') {
				if (ActivePlayerx == true)
				{
					Board[2][2] = 'X';
					ActivePlayerx = false;
					//Cell1Claimed = true;

				}
				else
				{
					ActivePlayerx = true;
					//Cell1Claimed = true;

				}
			}
			else {
				std::cout << "That space is taken!" << std::endl;
				std::cout << std::endl;
			}
		}

	}

	bool BoardDraw::WinCheck() const {
		bool GameWon = false;

		//Checks rows then columns then diagonals, needs to be optimized

		for (int x = 0; x < 3; x++) {
				if ((Board[x][0] == 'X' && Board[x][1] == 'X' && Board[x][2] == 'X') || (Board[x][0] == 'Y' && Board[x][1] == 'Y' && Board[x][2] == 'Y'))
				{

					GameWon = true;
				}
				else
				{
					GameWon = false;
					
				}

			if (GameWon)
			{
				std::cout << "Winner" << std::endl;
				return GameWon;
			}

		}

		for (int x = 0; x < 3; x++) {
			if ((Board[0][x] == 'X' && Board[1][x] == 'X' && Board[2][x] == 'X') || (Board[x][0] == 'Y' && Board[x][1] == 'Y' && Board[x][2] == 'Y'))
			{

				GameWon = true;
			}
			else
			{
				GameWon = false;

			}

			if (GameWon)
			{
				std::cout << "Winner" << std::endl;
				return GameWon;
			}

		}

		if (Board[0][0] == 'X' && Board[1][1] == 'X' && Board[2][2] == 'X' || Board[0][0] == 'Y' && Board[1][1] == 'Y' && Board[2][2] == 'Y')
		{
			GameWon = true;
		}

		if (Board[0][2] == 'X' && Board[1][1] == 'X' && Board[2][0] == 'X' || Board[0][2] == 'Y' && Board[1][1] == 'Y' && Board[2][0] == 'Y')
		{
			GameWon = true;
		}
		
		return GameWon;


	}	
	
	//};


	int main() {
		//Creates board object and then runs the methods on it in a loop

		BoardDraw boardinstance;

		bool GameFinished = false;

		boardinstance.InitializeBoard();

		do {
			boardinstance.PrintBoard();
			boardinstance.PlayerPlay();
			GameFinished = boardinstance.WinCheck();

		} while (!GameFinished);

		//Win text
		std::cout << std::endl << std::endl;
		boardinstance.PrintBoard();
		std::cout << std::endl << std::endl << "You Win! Game Over - wasn't that fun?";


		return 0;
	}


