#pragma once

constexpr int GridSize = 3;
bool ActivePlayerx = true;

class BoardDraw {

public:

    void InitializeBoard();
    void PrintBoard();
    void PlayerPlay();
    bool WinCheck() const;
    char Board[3][3];
};