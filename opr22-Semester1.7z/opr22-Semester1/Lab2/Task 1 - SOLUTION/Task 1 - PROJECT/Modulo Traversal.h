#pragma once

int Location = 0;
int loopCounter;
int GridSize;