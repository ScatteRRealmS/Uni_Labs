#include <iostream>
#include <conio.h>

//2D Array traversal

int main()
{
	//Sets the variables for the 2d array

	int Location = 0;
	int GridSize = 3;
	int LoopCounter = 0;
	//Creates the 2D array
	const char Board[3][3] = {
		{'h','e','l'},
		{'l','o','m'},
		{'a','t','e'}
	};

	//Introduction string

	std::cout << "Press SPACEBAR to traverse a 3x3 board and 'q' to quit" << std::endl;

	//Take a user input
	unsigned char KeyPressed = '\0';
	KeyPressed = _getch();

	do {
		if (KeyPressed == ' ')
		{
			//Sets current row and column using modulo math
			int Row = (Location / GridSize);
			int Column = (Location % GridSize);

			//Condition to loop the counter once it reaches its end
			//Could be modifiied to caculate what Row is equal to if I wanted to have it scale with the size of the array
			if (Row >= 3) {
				Column = 0;
				Row = 0;
				Location = 0;
			}

			//Prints out current values
			std::cout << "Row: " << Row + 1 << " | " << "Column: " << Column + 1 << " | " << "Found: " << Board[Location / GridSize][Location % GridSize] << std::endl;
			Location += 1;
			//Takes user input
			KeyPressed = _getch();
			//Counts a loop each time the counts reset
			if (Row == 1 && Column == 1) {
				LoopCounter += 1;

			}
			//Resets the counter once it reaches the end, could also modify this to calculate the > number
			if (Row > 3){
				Column = 0;
				Row = 0;
				Location = 0;
			}

		}
		//Waits for user to choose to quit
	} while (KeyPressed != 'q');
	//Prints string of how many loops
	std::cout << "Quit program after " << LoopCounter << " loops...";

	return 0;
	
}