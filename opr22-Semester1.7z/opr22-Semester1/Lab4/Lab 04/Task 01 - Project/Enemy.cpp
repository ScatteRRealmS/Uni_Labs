#include <iostream>
#include "Enemy.h"

Enemy::Enemy()
{
	int X = rand() % 200;
	int Y = rand() % 200;

	std::cout << "Constructor called on object at: " << this << " (Enemy)." << std::endl;
}

Enemy::~Enemy()
{
	std::cout << "Destructor called on object at: " << this << " (Enemy)." << std::endl;
}

void Enemy::Draw(MonsterWorld* World, olc::Sprite* Tileset) const
{
	World->DrawPartialSprite(SpritePosition, Tileset, SpriteOffset, SpriteSize);
	/*World->DrawPartialSprite(SpritePosition, Tileset, SpriteSize, SpriteOffset, SpriteScale);*/

}

void Enemy::MakeNoise() const
{
	std::cout << "Enemy [" << this << "] makes generic noise." << std::endl;
}

