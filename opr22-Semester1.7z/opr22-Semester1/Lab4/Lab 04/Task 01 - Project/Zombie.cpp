#include <iostream>
#include "Zombie.h"

Zombie::Zombie()
{
	std::cout << "Constructor called on object at: " << this << " (Zombie)." << std::endl;
}

Zombie::~Zombie()
{
	std::cout << "Destructor called on object at: " << this << " (Zombie)." << std::endl;
}

void Zombie::MakeNoise() const
{
	std::cout << "Zombie [" << this << "] makes OHHH, AHHHHHYAAAA noise." << std::endl;
}

void Zombie::Draw(MonsterWorld* World, olc::Sprite* Tileset) const
{
	World->DrawPartialSprite(SpritePosition, Tileset, SpriteOffset, SpriteSize);
	//World->DrawRect(X, Y, 16, 16, olc::BLUE);
}