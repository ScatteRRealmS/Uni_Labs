#include <iostream>
#define OLC_PGE_APPLICATION
#include "MonsterWorld.h"



constexpr int ArraySize = 8;
constexpr int SCREEN_WIDTH = 256;
constexpr int SCREEN_HEIGHT = 240;
constexpr int PIXEL_SIZE = 4;

int main()
{
	std::cout << "STARTING PROGRAM" << std::endl;

	MonsterWorld World;

	if (World.Construct(SCREEN_WIDTH, SCREEN_HEIGHT, PIXEL_SIZE, PIXEL_SIZE))
	{
		World.Start();
	}




	return 0;
}