#pragma once

#include "Enemy.h"

class Boss : public Enemy
{
public:
	Boss();
	~Boss();

	virtual void MakeNoise() const override;

	virtual void Draw(MonsterWorld* World, olc::Sprite* Tileset) const override;

protected:

	int X = rand() % 200;
	int Y = rand() % 200;

	const olc::vi2d SpriteSize = { 12, 12 };

	const olc::vi2d SpriteOffset = { 494, 130 };

	const olc::vi2d SpritePosition = { X, Y };

	const int SpriteScale = 3;

};

