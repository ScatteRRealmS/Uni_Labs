#pragma once

#include "olcPixelGameEngine.h"

//Forward declaration

class Enemy;

class MonsterWorld : public olc::PixelGameEngine
{
public:
	MonsterWorld();
	~MonsterWorld();

	virtual bool OnUserCreate() override;
	virtual bool OnUserUpdate(float fElapsedTime) override;

	olc::Sprite* Tileset = new olc::Sprite("tileset.png");
	//std::shared_ptr<olc::Sprite> Tileset = std::make_shared<olc::Sprite>("tileset.png");

protected:
	Enemy** EnemyPtrs = nullptr;


};