#pragma once

#include "MonsterWorld.h"

class Enemy
{
public:
	Enemy();
	virtual ~Enemy();

	virtual void MakeNoise() const;

	virtual void Draw(MonsterWorld* World, olc::Sprite* Tileset) const;

protected:
	//The Enemies world position
	int X = rand() % 200;
	int Y = rand() % 200;

	const olc::vi2d SpriteSize = { 12, 12 };

	const olc::vi2d SpriteOffset = { 91, 117 };

	const olc::vi2d SpritePosition = { X, Y };

	const int SpriteScale = 1;



private:
	Enemy(const Enemy& InEnemy);

};
