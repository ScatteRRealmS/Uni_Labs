#pragma once
#include "Enemy.h"

class Zombie : public Enemy
{

public:
	Zombie();
	virtual ~Zombie();

	virtual void MakeNoise() const override;

	virtual void Draw(MonsterWorld* World, olc::Sprite* Tileset) const;

protected:

	int X = rand() % 200;
	int Y = rand() % 200;

	const olc::vi2d SpriteSize = { 12, 12 };

	const olc::vi2d SpriteOffset = { 520, 39 };

	const olc::vi2d SpritePosition = { X, Y };

	const int SpriteScale = 1;

};
