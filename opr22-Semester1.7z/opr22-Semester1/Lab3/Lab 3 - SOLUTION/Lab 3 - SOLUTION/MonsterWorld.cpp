#include <iostream>
#include "Zombie.h"
#include "Boss.h"
#include "Enemy.h"
#include "MonsterWorld.h"


MonsterWorld::MonsterWorld()
{
}

MonsterWorld::~MonsterWorld()
{
}

bool MonsterWorld::OnUserCreate()
{
	EnemyPtrs = new Enemy * [8];

	EnemyPtrs[0] = new Boss();
	EnemyPtrs[1] = new Enemy();
	EnemyPtrs[2] = new Enemy();
	EnemyPtrs[3] = new Enemy();
	EnemyPtrs[4] = new Enemy();

	EnemyPtrs[5] = new Zombie();
	EnemyPtrs[6] = new Zombie();
	EnemyPtrs[7] = new Zombie();
	return true;
}

bool MonsterWorld::OnUserUpdate(float fElapsedTime)
{
	for (int i = 0; i <= 7; i++)
	{
		EnemyPtrs[i]->Draw(this);
	}
	return true;
}
