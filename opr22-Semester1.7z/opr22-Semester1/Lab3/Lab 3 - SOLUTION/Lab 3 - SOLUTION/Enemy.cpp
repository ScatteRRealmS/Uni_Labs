#include <iostream>
#include "Enemy.h"

Enemy::Enemy()
{
		X = rand() % 200;
		Y = rand() % 200;

		std::cout << "Constructor called on object at: " << this << " (Enemy)." << std::endl;
}

Enemy::~Enemy()
{
	std::cout << "Destructor called on object at: " << this << " (Enemy)." << std::endl;
}

void Enemy::Draw(MonsterWorld* World) const
{

	World->DrawRect(X, Y, 8, 8, olc::RED);
}

void Enemy::MakeNoise() const
{
	std::cout << "Enemy [" << this << "] makes generic noise." << std::endl;
}

