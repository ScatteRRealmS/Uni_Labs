#pragma once
#include "Enemy.h"

class Zombie : public Enemy
{

public:
	Zombie();
	virtual ~Zombie();

	virtual void MakeNoise() const override;

	virtual void Draw(MonsterWorld* World) const;

};
