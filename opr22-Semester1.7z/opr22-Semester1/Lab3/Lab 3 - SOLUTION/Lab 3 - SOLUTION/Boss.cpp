#include <iostream>
#include "Boss.h"



Boss::Boss()
{

	std::cout << "Constructor called on object at: " << this << " (Boss)." << std::endl;
}

Boss::~Boss()
{
	std::cout << "Destructor called on object at: " << this << " (Boss)." << std::endl;
}

void Boss::MakeNoise() const
{
	std::cout << "Boss [" << this << "makes GRRAAAAUUUU noise" << std::endl;
}

void Boss::Draw(MonsterWorld* World) const
{
	World->DrawRect(X, Y, 32, 32, olc::YELLOW);
}
