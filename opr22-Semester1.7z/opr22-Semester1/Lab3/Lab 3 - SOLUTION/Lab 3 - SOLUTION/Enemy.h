#pragma once

#include "MonsterWorld.h"

class Enemy
{
public:
	Enemy();
	virtual ~Enemy();
		
	virtual void MakeNoise() const;

	virtual void Draw(MonsterWorld* World) const;

protected:
	//The Enemies world position
	int X;
	int Y;


private:
	Enemy(const Enemy& InEnemy);

};
