#pragma once
#include "Enemy.h"

class Boss : public Enemy
{
public:
	Boss();
	~Boss();

	virtual void MakeNoise() const override;

	virtual void Draw(MonsterWorld* World) const override;
};

