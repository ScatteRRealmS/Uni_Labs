#pragma once

#include "olcPixelGameEngine.h"

//Forward declaration

class Enemy;

class MonsterWorld : public olc::PixelGameEngine
{
public:
	MonsterWorld();
	~MonsterWorld();

	virtual bool OnUserCreate() override;
	virtual bool OnUserUpdate(float fElapsedTime) override;

protected:
	Enemy** EnemyPtrs = nullptr;


};
