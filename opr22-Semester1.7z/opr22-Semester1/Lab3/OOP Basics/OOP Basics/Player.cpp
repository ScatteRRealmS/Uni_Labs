#include <iostream>
#include "Player.h"


	Player::Player()
	{
		//Constructs the player with set values and an output message
		std::cout << "A Player Object Was Created" << std::endl;
		SetHealth(100);
		SetExperience(1);
		SetPowerUpLevel(1);

	}

	Player::~Player()
	{
		//Deconstructor with message
		std::cout << "A Player Object Was Destroyed" << std::endl;

	}

	void Player::SetHealth(int InHealth)
	{
		health += InHealth;
	}

	int Player::GetHealth() const
	{
		return health;
	}

	void Player::SetExperience(int InExperience)
	{
		experienceLevel += InExperience;
	}

	int Player::GetExperience() const
	{
		return experienceLevel;
	}

	void Player::SetPowerUpLevel(int inPowerLevel)
	{
		powerUpLevel += inPowerLevel;
	}

	int Player::GetPowerLevel() const
	{
		return powerUpLevel;
	}

	void Player::PrintStats()
	{
		//Displays everything about current player object
		std::cout << "------------" << std::endl;
		std::cout << "Player Stats: " << std::endl;
		std::cout << "Health: " << GetHealth() << std::endl;
		std::cout << "Experience Level: " << GetExperience() << std::endl;
		std::cout << "Power-Up Level: " << GetPowerLevel() << std::endl;
		std::cout << "------------" << std::endl;
	}
