#pragma once

class Player
{
public:
	//Constructor and destructor
	Player();
	~Player();

	//Functions as getters and setters

	void SetHealth(int InHealth);
	int GetHealth() const;

	void SetExperience(int InExperience);
	int GetExperience() const;

	void SetPowerUpLevel(int inPowerLevel);
	int GetPowerLevel() const;

	void PrintStats();

	//Declared variables for player class
private:
	int health = 0;
	int experienceLevel = 0;
	int powerUpLevel = 0;

};