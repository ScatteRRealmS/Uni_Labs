#include <iostream>
#include "Player.h"

void main()
{
	Player ReadyPlayerOne;
	ReadyPlayerOne.PrintStats();
	ReadyPlayerOne.SetExperience(4);
	ReadyPlayerOne.SetHealth(200);
	ReadyPlayerOne.SetPowerUpLevel(5);
	ReadyPlayerOne.PrintStats();
	Player *PlayerPointer = &ReadyPlayerOne;
	PlayerPointer = nullptr;
	PlayerPointer = new Player;
	PlayerPointer->SetHealth(50);
	PlayerPointer->PrintStats();
	delete PlayerPointer;
}